rootProject.name = "ktor-DotaX"
